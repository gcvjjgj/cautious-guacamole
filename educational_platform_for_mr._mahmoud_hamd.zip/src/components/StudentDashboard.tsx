import { useState } from "react";
import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";
import { SignOutButton } from "../SignOutButton";

interface StudentDashboardProps {
  onBack: () => void;
  toggleTheme: () => void;
  isDarkMode: boolean;
}

export function StudentDashboard({ onBack, toggleTheme, isDarkMode }: StudentDashboardProps) {
  const [activeTab, setActiveTab] = useState('lessons');
  const student = useQuery(api.students.getCurrentStudent);
  const walletBalance = useQuery(api.students.getWalletBalance);
  const unreadCount = useQuery(api.notifications.getUnreadCount);

  if (student === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (!student) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-4">
            لم يتم العثور على بيانات الطالب
          </h2>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            رجوع
          </button>
        </div>
      </div>
    );
  }

  if (student.isBlocked) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl max-w-md mx-auto text-center">
          <div className="text-6xl mb-4">🚫</div>
          <h2 className="text-2xl font-bold text-red-600 dark:text-red-400 mb-4">
            تم حظر الحساب
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-6">
            {student.blockReason || "تم حظر حسابك. يرجى التواصل مع الدعم الفني."}
          </p>
          <button
            onClick={onBack}
            className="px-6 py-3 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
          >
            رجوع
          </button>
        </div>
      </div>
    );
  }

  const menuItems = [
    { id: 'lessons', label: '💡 الحصص المدفوعة', icon: '💡' },
    { id: 'subscriptions', label: '🧾 الاشتراكات', icon: '🧾' },
    { id: 'books', label: '📚 الكتب', icon: '📚' },
    { id: 'support', label: '🛠️ الدعم الفني', icon: '🛠️' },
    { id: 'wallet', label: '💳 المحفظة', icon: '💳' },
    { id: 'activity', label: '📑 سجل النشاط', icon: '📑' },
    { id: 'notifications', label: `🛎️ الإشعارات ${unreadCount ? `(${unreadCount})` : ''}`, icon: '🛎️' },
    { id: 'settings', label: '⚙️ الإعدادات', icon: '⚙️' },
  ];

  return (
    <div className="min-h-screen">
      {/* Header */}
      <header className="bg-white dark:bg-gray-800 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                ← رجوع
              </button>
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                لوحة تحكم الطالب
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="text-sm text-gray-600 dark:text-gray-300">
                مرحباً، {student.fullName}
              </div>
              <div className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-3 py-1 rounded-full text-sm">
                الرصيد: {walletBalance || 0} جنيه
              </div>
              <button
                onClick={toggleTheme}
                className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {isDarkMode ? '☀️' : '🌙'}
              </button>
              <SignOutButton />
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
              <nav className="space-y-2">
                {menuItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full text-right px-4 py-3 rounded-lg transition-colors ${
                      activeTab === item.id
                        ? 'bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200'
                        : 'hover:bg-gray-100 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    <span className="mr-2">{item.icon}</span>
                    {item.label}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-3">
            <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6">
              {activeTab === 'lessons' && <LessonsTab student={student} />}
              {activeTab === 'subscriptions' && <SubscriptionsTab />}
              {activeTab === 'books' && <BooksTab />}
              {activeTab === 'support' && <SupportTab />}
              {activeTab === 'wallet' && <WalletTab />}
              {activeTab === 'activity' && <ActivityTab />}
              {activeTab === 'notifications' && <NotificationsTab />}
              {activeTab === 'settings' && <SettingsTab student={student} />}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Placeholder components for each tab
function LessonsTab({ student }: { student: any }) {
  const lessons = useQuery(api.lessons.getLessonsByGrade, { grade: student.grade });
  const studentLessons = useQuery(api.students.getStudentLessons);

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        💡 الحصص المدفوعة
      </h2>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {lessons?.map((lesson) => {
          const studentLesson = studentLessons?.find((sl: any) => sl.lessonId === lesson._id);
          const isPurchased = !!studentLesson;
          
          return (
            <div key={lesson._id} className="bg-gray-50 dark:bg-gray-700 rounded-xl p-4">
              <img
                src={lesson.coverImageUrl || '/placeholder-lesson.jpg'}
                alt={lesson.title}
                className="w-full h-32 object-cover rounded-lg mb-4"
              />
              <h3 className="font-bold text-gray-800 dark:text-white mb-2">
                {lesson.title}
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm mb-4">
                {lesson.description}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-green-600 dark:text-green-400 font-bold">
                  {lesson.price} جنيه
                </span>
                {isPurchased ? (
                  <span className="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 px-3 py-1 rounded-full text-sm">
                    مشترى
                  </span>
                ) : (
                  <button className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    شراء
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function SubscriptionsTab() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        🧾 الاشتراكات
      </h2>
      <p className="text-gray-600 dark:text-gray-300">
        قريباً... باقات شهرية تشمل حصص مدمجة
      </p>
    </div>
  );
}

function BooksTab() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        📚 الكتب
      </h2>
      <p className="text-gray-600 dark:text-gray-300">
        قريباً... حجز الكتب مع خدمة التوصيل
      </p>
    </div>
  );
}

function SupportTab() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        🛠️ الدعم الفني
      </h2>
      <p className="text-gray-600 dark:text-gray-300">
        قريباً... دردشة مباشرة مع فريق الدعم
      </p>
    </div>
  );
}

function WalletTab() {
  const transactions = useQuery(api.wallet.getWalletTransactions);

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        💳 المحفظة
      </h2>
      
      <div className="mb-6">
        <button className="bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition-colors">
          شحن الرصيد
        </button>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 dark:text-white">
          سجل المعاملات
        </h3>
        
        {transactions?.map((transaction) => (
          <div key={transaction._id} className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-800 dark:text-white">
                  {transaction.description}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {new Date(transaction.timestamp).toLocaleDateString('ar-EG')}
                </p>
              </div>
              <div className="text-right">
                <p className={`font-bold ${
                  transaction.type === 'deposit' 
                    ? 'text-green-600 dark:text-green-400' 
                    : 'text-red-600 dark:text-red-400'
                }`}>
                  {transaction.type === 'deposit' ? '+' : '-'}{transaction.amount} جنيه
                </p>
                <p className={`text-sm ${
                  transaction.status === 'approved' 
                    ? 'text-green-600 dark:text-green-400'
                    : transaction.status === 'rejected'
                    ? 'text-red-600 dark:text-red-400'
                    : 'text-yellow-600 dark:text-yellow-400'
                }`}>
                  {transaction.status === 'approved' ? 'مؤكد' : 
                   transaction.status === 'rejected' ? 'مرفوض' : 'قيد المراجعة'}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ActivityTab() {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        📑 سجل النشاط
      </h2>
      <p className="text-gray-600 dark:text-gray-300">
        قريباً... سجل شامل لجميع أنشطتك
      </p>
    </div>
  );
}

function NotificationsTab() {
  const notifications = useQuery(api.notifications.getNotifications);

  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        🛎️ الإشعارات
      </h2>
      
      <div className="space-y-4">
        {notifications?.map((notification) => (
          <div 
            key={notification._id} 
            className={`p-4 rounded-lg border-r-4 ${
              notification.type === 'success' 
                ? 'bg-green-50 dark:bg-green-900/20 border-green-500'
                : notification.type === 'warning'
                ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-500'
                : notification.type === 'error'
                ? 'bg-red-50 dark:bg-red-900/20 border-red-500'
                : 'bg-blue-50 dark:bg-blue-900/20 border-blue-500'
            } ${!notification.isRead ? 'ring-2 ring-blue-200 dark:ring-blue-800' : ''}`}
          >
            <div className="flex items-start justify-between">
              <div>
                <h4 className="font-semibold text-gray-800 dark:text-white">
                  {notification.title}
                </h4>
                <p className="text-gray-600 dark:text-gray-300 mt-1">
                  {notification.message}
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400 mt-2">
                  {new Date(notification.timestamp).toLocaleString('ar-EG')}
                </p>
              </div>
              {!notification.isRead && (
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
              )}
            </div>
          </div>
        ))}
        
        {!notifications?.length && (
          <p className="text-gray-600 dark:text-gray-300 text-center py-8">
            لا توجد إشعارات
          </p>
        )}
      </div>
    </div>
  );
}

function SettingsTab({ student }: { student: any }) {
  return (
    <div>
      <h2 className="text-2xl font-bold text-gray-800 dark:text-white mb-6">
        ⚙️ الإعدادات
      </h2>
      
      <div className="space-y-6">
        <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-4">
          <h3 className="font-semibold text-gray-800 dark:text-white mb-4">
            معلومات الحساب
          </h3>
          <div className="space-y-2">
            <p className="text-gray-600 dark:text-gray-300">
              <span className="font-medium">الاسم:</span> {student.fullName}
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              <span className="font-medium">رقم الطالب:</span> {student.studentNumber}
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              <span className="font-medium">الصف:</span> {
                student.grade === 'first' ? 'الأول الثانوي' :
                student.grade === 'second' ? 'الثاني الثانوي' :
                'الثالث الثانوي'
              }
            </p>
            <p className="text-gray-600 dark:text-gray-300">
              <span className="font-medium">رقم ولي الأمر:</span> {student.parentPhone}
            </p>
          </div>
        </div>
        
        <button className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors">
          تعديل البيانات
        </button>
      </div>
    </div>
  );
}
