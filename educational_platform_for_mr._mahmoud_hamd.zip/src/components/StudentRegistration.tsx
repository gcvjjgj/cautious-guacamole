import { useState } from "react";
import { useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";

interface StudentRegistrationProps {
  onBack: () => void;
}

export function StudentRegistration({ onBack }: StudentRegistrationProps) {
  const [formData, setFormData] = useState({
    fullName: "",
    studentNumber: "",
    parentPhone: "",
    grade: "first" as "first" | "second" | "third",
    password: "",
    confirmPassword: "",
  });

  const registerStudent = useMutation(api.students.registerStudent);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (formData.password !== formData.confirmPassword) {
      toast.error("كلمات المرور غير متطابقة");
      return;
    }

    if (formData.password.length < 6) {
      toast.error("كلمة المرور يجب أن تكون 6 أحرف على الأقل");
      return;
    }

    try {
      await registerStudent({
        fullName: formData.fullName,
        studentNumber: formData.studentNumber,
        parentPhone: formData.parentPhone,
        grade: formData.grade,
        password: formData.password,
      });

      toast.success("تم إنشاء الحساب بنجاح!");
      onBack();
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "حدث خطأ أثناء إنشاء الحساب");
    }
  };

  const gradeOptions = [
    { value: "first", label: "الصف الأول الثانوي" },
    { value: "second", label: "الصف الثاني الثانوي" },
    { value: "third", label: "الصف الثالث الثانوي" },
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          الاسم الرباعي
        </label>
        <input
          type="text"
          required
          value={formData.fullName}
          onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="أدخل الاسم الرباعي"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          رقم الطالب
        </label>
        <input
          type="text"
          required
          value={formData.studentNumber}
          onChange={(e) => setFormData({ ...formData, studentNumber: e.target.value })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="أدخل رقم الطالب"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          رقم ولي الأمر
        </label>
        <input
          type="tel"
          required
          value={formData.parentPhone}
          onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="أدخل رقم ولي الأمر"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          الصف الدراسي
        </label>
        <select
          value={formData.grade}
          onChange={(e) => setFormData({ ...formData, grade: e.target.value as "first" | "second" | "third" })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
        >
          {gradeOptions.map((option) => (
            <option key={option.value} value={option.value}>
              {option.label}
            </option>
          ))}
        </select>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          كلمة المرور
        </label>
        <input
          type="password"
          required
          value={formData.password}
          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="أدخل كلمة المرور"
        />
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          تأكيد كلمة المرور
        </label>
        <input
          type="password"
          required
          value={formData.confirmPassword}
          onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
          className="auth-input-field dark:bg-gray-700 dark:border-gray-600 dark:text-white"
          placeholder="أعد إدخال كلمة المرور"
        />
      </div>

      <div className="flex gap-3 pt-4">
        <button
          type="button"
          onClick={onBack}
          className="flex-1 px-4 py-3 rounded bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-300 font-semibold hover:bg-gray-400 dark:hover:bg-gray-500 transition-colors"
        >
          رجوع
        </button>
        <button
          type="submit"
          className="flex-1 auth-button"
        >
          إنشاء حساب
        </button>
      </div>
    </form>
  );
}
