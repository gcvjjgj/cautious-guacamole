interface TeacherDashboardProps {
  onBack: () => void;
  toggleTheme: () => void;
  isDarkMode: boolean;
}

export function TeacherDashboard({ onBack, toggleTheme, isDarkMode }: TeacherDashboardProps) {
  return (
    <div className="min-h-screen">
      <header className="bg-white dark:bg-gray-800 shadow-lg">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              >
                ← رجوع
              </button>
              <h1 className="text-2xl font-bold text-gray-800 dark:text-white">
                لوحة تحكم المدرس
              </h1>
            </div>
            
            <div className="flex items-center gap-4">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-full bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors"
              >
                {isDarkMode ? '☀️' : '🌙'}
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-800 dark:text-white mb-4">
            👨‍🏫 لوحة تحكم المدرس
          </h2>
          <p className="text-gray-600 dark:text-gray-300">
            قريباً... واجهة إدارة النظام الكاملة
          </p>
        </div>
      </div>
    </div>
  );
}
