import { Authenticated, Unauthenticated, useQuery } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { useState, useEffect } from "react";
import { StudentDashboard } from "./components/StudentDashboard";
import { SupportDashboard } from "./components/SupportDashboard";
import { TeacherDashboard } from "./components/TeacherDashboard";
import { StudentRegistration } from "./components/StudentRegistration";

export default function App() {
  const [userType, setUserType] = useState<'student' | 'support' | 'teacher' | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark') {
      setIsDarkMode(true);
      document.documentElement.classList.add('dark');
    }
  }, []);

  const toggleTheme = () => {
    setIsDarkMode(!isDarkMode);
    if (!isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  };

  if (userType === 'student') {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
          <Authenticated>
            <StudentDashboard onBack={() => setUserType(null)} toggleTheme={toggleTheme} isDarkMode={isDarkMode} />
          </Authenticated>
          <Unauthenticated>
            <StudentAuth onBack={() => setUserType(null)} />
          </Unauthenticated>
          <Toaster />
        </div>
      </div>
    );
  }

  if (userType === 'support') {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 dark:from-gray-900 dark:to-gray-800">
          <SupportDashboard onBack={() => setUserType(null)} toggleTheme={toggleTheme} isDarkMode={isDarkMode} />
          <Toaster />
        </div>
      </div>
    );
  }

  if (userType === 'teacher') {
    return (
      <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
        <div className="min-h-screen bg-gradient-to-br from-purple-50 to-violet-100 dark:from-gray-900 dark:to-gray-800">
          <TeacherDashboard onBack={() => setUserType(null)} toggleTheme={toggleTheme} isDarkMode={isDarkMode} />
          <Toaster />
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen ${isDarkMode ? 'dark' : ''}`}>
      <div className="min-h-screen bg-gradient-to-br from-indigo-100 via-purple-50 to-pink-100 dark:from-gray-900 dark:to-gray-800">
        <div className="container mx-auto px-4 py-8">
          <div className="text-center mb-12">
            <div className="flex justify-between items-center mb-8">
              <div></div>
              <button
                onClick={toggleTheme}
                className="p-2 rounded-full bg-white dark:bg-gray-800 shadow-lg hover:shadow-xl transition-all duration-300"
              >
                {isDarkMode ? '☀️' : '🌙'}
              </button>
            </div>
            
            <h1 className="text-6xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-purple-600 dark:from-blue-400 dark:to-purple-400 mb-4">
              مستر محمود حمد
            </h1>
            <h2 className="text-3xl font-semibold text-gray-700 dark:text-gray-300 mb-6">
              مدرس أول لغة إنجليزية
            </h2>
            
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-2xl max-w-2xl mx-auto mb-12">
              <p className="text-lg text-gray-600 dark:text-gray-300 leading-relaxed">
                مرحبًا بك في عالم مستر محمود حمد.. هنا يبدأ طريقك نحو التفوق! 
                بين هذه الصفحات ستجد رفيقًا تعليميًا متكاملًا: شرح مدروس، واجبات، 
                امتحانات تفاعلية، ومتابعة لحظية. كل هذا وأنت مرتاح في منزلك. 
                🔝 اضغط على 'دخول' لتبدأ رحلتك!
              </p>
            </div>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <UserTypeCard
              icon="👨‍🎓"
              title="طالب"
              description="الوصول للحصص والاشتراكات"
              color="from-blue-500 to-blue-600"
              onClick={() => setUserType('student')}
            />
            
            <UserTypeCard
              icon="🧑‍🔧"
              title="دعم فني"
              description="إدارة الطلاب والمساعدة"
              color="from-green-500 to-green-600"
              onClick={() => setUserType('support')}
            />
            
            <UserTypeCard
              icon="👨‍🏫"
              title="مدرس"
              description="إدارة النظام والمحتوى"
              color="from-purple-500 to-purple-600"
              onClick={() => setUserType('teacher')}
            />
          </div>
        </div>
        <Toaster />
      </div>
    </div>
  );
}

function UserTypeCard({ 
  icon, 
  title, 
  description, 
  color, 
  onClick 
}: {
  icon: string;
  title: string;
  description: string;
  color: string;
  onClick: () => void;
}) {
  return (
    <div
      onClick={onClick}
      className="group cursor-pointer transform hover:scale-105 transition-all duration-300"
    >
      <div className="bg-white dark:bg-gray-800 rounded-2xl p-8 shadow-xl hover:shadow-2xl transition-all duration-300">
        <div className={`w-20 h-20 mx-auto mb-6 rounded-full bg-gradient-to-r ${color} flex items-center justify-center text-3xl shadow-lg group-hover:shadow-xl transition-all duration-300`}>
          {icon}
        </div>
        <h3 className="text-2xl font-bold text-gray-800 dark:text-white mb-3 text-center">
          {title}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 text-center">
          {description}
        </p>
      </div>
    </div>
  );
}

function StudentAuth({ onBack }: { onBack: () => void }) {
  const [isRegistering, setIsRegistering] = useState(false);

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-2xl p-8">
          <div className="flex items-center mb-6">
            <button
              onClick={onBack}
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200 mr-4"
            >
              ← رجوع
            </button>
            <h2 className="text-2xl font-bold text-gray-800 dark:text-white">
              {isRegistering ? 'إنشاء حساب جديد' : 'تسجيل دخول الطالب'}
            </h2>
          </div>

          {isRegistering ? (
            <StudentRegistration onBack={() => setIsRegistering(false)} />
          ) : (
            <div>
              <SignInForm />
              <div className="mt-6 text-center">
                <button
                  onClick={() => setIsRegistering(true)}
                  className="text-blue-600 dark:text-blue-400 hover:underline"
                >
                  ليس لديك حساب؟ إنشاء حساب جديد
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
