import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  // Students table
  students: defineTable({
    fullName: v.string(),
    studentNumber: v.string(),
    parentPhone: v.string(),
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
    walletBalance: v.number(),
    isBlocked: v.boolean(),
    blockReason: v.optional(v.string()),
    userId: v.id("users"),
  })
    .index("by_user", ["userId"])
    .index("by_student_number", ["studentNumber"]),

  // Support staff table
  supportStaff: defineTable({
    name: v.string(),
    code: v.string(),
    isOnline: v.boolean(),
    lastSeen: v.number(),
    addedBy: v.id("users"),
  })
    .index("by_code", ["code"]),

  // Lessons table
  lessons: defineTable({
    title: v.string(),
    description: v.string(),
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
    price: v.number(),
    coverImage: v.id("_storage"),
    videoUrl: v.id("_storage"),
    pdfUrl: v.id("_storage"),
    homeworkUrl: v.id("_storage"),
    homeworkSolutionUrl: v.id("_storage"),
    examQuestions: v.array(v.object({
      question: v.string(),
      options: v.array(v.string()),
      correctAnswer: v.number(),
    })),
    order: v.number(),
    isActive: v.boolean(),
  })
    .index("by_grade", ["grade"])
    .index("by_order", ["order"]),

  // Student lesson progress
  studentLessons: defineTable({
    studentId: v.id("students"),
    lessonId: v.id("lessons"),
    isPurchased: v.boolean(),
    hasWatchedVideo: v.boolean(),
    examAttempts: v.number(),
    examScore: v.optional(v.number()),
    hasPassed: v.boolean(),
    purchaseDate: v.number(),
  })
    .index("by_student", ["studentId"])
    .index("by_lesson", ["lessonId"])
    .index("by_student_lesson", ["studentId", "lessonId"]),

  // Subscriptions table
  subscriptions: defineTable({
    title: v.string(),
    description: v.string(),
    price: v.number(),
    duration: v.number(), // in days
    includedLessons: v.array(v.id("lessons")),
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
    isActive: v.boolean(),
  })
    .index("by_grade", ["grade"]),

  // Student subscriptions
  studentSubscriptions: defineTable({
    studentId: v.id("students"),
    subscriptionId: v.id("subscriptions"),
    startDate: v.number(),
    endDate: v.number(),
    isActive: v.boolean(),
  })
    .index("by_student", ["studentId"])
    .index("by_subscription", ["subscriptionId"]),

  // Books table
  books: defineTable({
    title: v.string(),
    description: v.string(),
    price: v.number(),
    coverImage: v.id("_storage"),
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
    isAvailable: v.boolean(),
  })
    .index("by_grade", ["grade"]),

  // Book orders
  bookOrders: defineTable({
    studentId: v.id("students"),
    bookId: v.id("books"),
    deliveryName: v.string(),
    deliveryPhone: v.string(),
    deliveryAddress: v.string(),
    orderDate: v.number(),
    status: v.union(v.literal("pending"), v.literal("confirmed"), v.literal("delivered")),
    ticketNumber: v.string(),
  })
    .index("by_student", ["studentId"])
    .index("by_ticket", ["ticketNumber"]),

  // Support messages
  supportMessages: defineTable({
    studentId: v.id("students"),
    staffId: v.optional(v.id("supportStaff")),
    message: v.string(),
    imageUrl: v.optional(v.id("_storage")),
    isFromStudent: v.boolean(),
    timestamp: v.number(),
    isRead: v.boolean(),
  })
    .index("by_student", ["studentId"])
    .index("by_staff", ["staffId"])
    .index("by_timestamp", ["timestamp"]),

  // Wallet transactions
  walletTransactions: defineTable({
    studentId: v.id("students"),
    amount: v.number(),
    type: v.union(v.literal("deposit"), v.literal("withdrawal")),
    description: v.string(),
    paymentMethod: v.optional(v.string()),
    paymentProof: v.optional(v.id("_storage")),
    status: v.union(v.literal("pending"), v.literal("approved"), v.literal("rejected")),
    rejectionReason: v.optional(v.string()),
    timestamp: v.number(),
    processedBy: v.optional(v.id("supportStaff")),
  })
    .index("by_student", ["studentId"])
    .index("by_status", ["status"])
    .index("by_timestamp", ["timestamp"]),

  // Notifications
  notifications: defineTable({
    studentId: v.id("students"),
    title: v.string(),
    message: v.string(),
    type: v.union(v.literal("success"), v.literal("warning"), v.literal("error"), v.literal("info")),
    isRead: v.boolean(),
    timestamp: v.number(),
  })
    .index("by_student", ["studentId"])
    .index("by_timestamp", ["timestamp"]),

  // External links
  externalLinks: defineTable({
    title: v.string(),
    url: v.string(),
    grade: v.optional(v.union(v.literal("first"), v.literal("second"), v.literal("third"))),
    isActive: v.boolean(),
    addedBy: v.id("users"),
    timestamp: v.number(),
  })
    .index("by_grade", ["grade"])
    .index("by_active", ["isActive"]),

  // General messages from teacher
  generalMessages: defineTable({
    title: v.string(),
    message: v.string(),
    targetGrade: v.optional(v.union(v.literal("first"), v.literal("second"), v.literal("third"))),
    expiryDate: v.number(),
    isActive: v.boolean(),
    timestamp: v.number(),
  })
    .index("by_active", ["isActive"])
    .index("by_grade", ["targetGrade"]),

  // App settings
  appSettings: defineTable({
    key: v.string(),
    value: v.string(),
    updatedBy: v.id("users"),
    timestamp: v.number(),
  })
    .index("by_key", ["key"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
