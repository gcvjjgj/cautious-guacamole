import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Register a new student
export const registerStudent = mutation({
  args: {
    fullName: v.string(),
    studentNumber: v.string(),
    parentPhone: v.string(),
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
    password: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    // Check if student number already exists
    const existingStudent = await ctx.db
      .query("students")
      .withIndex("by_student_number", (q) => q.eq("studentNumber", args.studentNumber))
      .first();

    if (existingStudent) {
      throw new Error("Student number already exists");
    }

    const studentId = await ctx.db.insert("students", {
      fullName: args.fullName,
      studentNumber: args.studentNumber,
      parentPhone: args.parentPhone,
      grade: args.grade,
      walletBalance: 0,
      isBlocked: false,
      userId,
    });

    return studentId;
  },
});

// Get current student profile
export const getCurrentStudent = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return student;
  },
});

// Update student profile
export const updateStudentProfile = mutation({
  args: {
    fullName: v.optional(v.string()),
    parentPhone: v.optional(v.string()),
    oldPassword: v.string(),
    changeReason: v.string(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    if (student.isBlocked) {
      throw new Error("Account is blocked");
    }

    // Create a support message for profile change request
    await ctx.db.insert("supportMessages", {
      studentId: student._id,
      message: `Profile change request: ${args.changeReason}`,
      isFromStudent: true,
      timestamp: Date.now(),
      isRead: false,
    });

    // Create notification
    await ctx.db.insert("notifications", {
      studentId: student._id,
      title: "Profile Change Request",
      message: "Your profile change request has been submitted for approval",
      type: "info",
      isRead: false,
      timestamp: Date.now(),
    });

    return "Profile change request submitted";
  },
});

// Get student wallet balance
export const getWalletBalance = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return null;
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    return student?.walletBalance || 0;
  },
});

// Get student's purchased lessons
export const getStudentLessons = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      return [];
    }

    const studentLessons = await ctx.db
      .query("studentLessons")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .filter((q) => q.eq(q.field("isPurchased"), true))
      .collect();

    return studentLessons;
  },
});

// Get student activity log
export const getActivityLog = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      return [];
    }

    // Get lesson progress
    const lessonProgress = await ctx.db
      .query("studentLessons")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .collect();

    // Get wallet transactions
    const transactions = await ctx.db
      .query("walletTransactions")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .collect();

    // Get subscriptions
    const subscriptions = await ctx.db
      .query("studentSubscriptions")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .collect();

    return {
      lessonProgress,
      transactions,
      subscriptions,
    };
  },
});
