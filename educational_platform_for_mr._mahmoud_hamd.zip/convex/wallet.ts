import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Request wallet recharge
export const requestRecharge = mutation({
  args: {
    amount: v.number(),
    paymentMethod: v.string(),
    paymentProof: v.id("_storage"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    if (student.isBlocked) {
      throw new Error("Account is blocked");
    }

    await ctx.db.insert("walletTransactions", {
      studentId: student._id,
      amount: args.amount,
      type: "deposit",
      description: `Wallet recharge request - ${args.paymentMethod}`,
      paymentMethod: args.paymentMethod,
      paymentProof: args.paymentProof,
      status: "pending",
      timestamp: Date.now(),
    });

    // Create notification
    await ctx.db.insert("notifications", {
      studentId: student._id,
      title: "Recharge Request Submitted",
      message: `Your recharge request of ${args.amount} EGP is being processed`,
      type: "info",
      isRead: false,
      timestamp: Date.now(),
    });

    return "Recharge request submitted successfully";
  },
});

// Get wallet transactions
export const getWalletTransactions = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      return [];
    }

    const transactions = await ctx.db
      .query("walletTransactions")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .order("desc")
      .collect();

    return Promise.all(
      transactions.map(async (transaction) => ({
        ...transaction,
        paymentProofUrl: transaction.paymentProof 
          ? await ctx.storage.getUrl(transaction.paymentProof)
          : null,
      }))
    );
  },
});

// Generate upload URL for payment proof
export const generatePaymentProofUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
