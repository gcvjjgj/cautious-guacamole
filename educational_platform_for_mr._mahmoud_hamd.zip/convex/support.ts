import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Send support message
export const sendSupportMessage = mutation({
  args: {
    message: v.string(),
    imageUrl: v.optional(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    await ctx.db.insert("supportMessages", {
      studentId: student._id,
      message: args.message,
      imageUrl: args.imageUrl,
      isFromStudent: true,
      timestamp: Date.now(),
      isRead: false,
    });

    return "Message sent successfully";
  },
});

// Get support messages
export const getSupportMessages = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      return [];
    }

    const messages = await ctx.db
      .query("supportMessages")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .order("asc")
      .collect();

    return Promise.all(
      messages.map(async (message) => ({
        ...message,
        imageUrl: message.imageUrl 
          ? await ctx.storage.getUrl(message.imageUrl)
          : null,
      }))
    );
  },
});

// Generate upload URL for support image
export const generateSupportImageUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    return await ctx.storage.generateUploadUrl();
  },
});
