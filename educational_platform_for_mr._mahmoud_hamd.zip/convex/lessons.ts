import { v } from "convex/values";
import { query, mutation } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

// Get lessons by grade
export const getLessonsByGrade = query({
  args: {
    grade: v.union(v.literal("first"), v.literal("second"), v.literal("third")),
  },
  handler: async (ctx, args) => {
    const lessons = await ctx.db
      .query("lessons")
      .withIndex("by_grade", (q) => q.eq("grade", args.grade))
      .filter((q) => q.eq(q.field("isActive"), true))
      .collect();

    return Promise.all(
      lessons.map(async (lesson) => ({
        ...lesson,
        coverImageUrl: await ctx.storage.getUrl(lesson.coverImage),
      }))
    );
  },
});

// Purchase a lesson
export const purchaseLesson = mutation({
  args: {
    lessonId: v.id("lessons"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    if (student.isBlocked) {
      throw new Error("Account is blocked");
    }

    const lesson = await ctx.db.get(args.lessonId);
    if (!lesson) {
      throw new Error("Lesson not found");
    }

    if (student.walletBalance < lesson.price) {
      throw new Error("Insufficient balance");
    }

    // Check if already purchased
    const existingPurchase = await ctx.db
      .query("studentLessons")
      .withIndex("by_student_lesson", (q) => 
        q.eq("studentId", student._id).eq("lessonId", args.lessonId)
      )
      .first();

    if (existingPurchase) {
      throw new Error("Lesson already purchased");
    }

    // Deduct from wallet
    await ctx.db.patch(student._id, {
      walletBalance: student.walletBalance - lesson.price,
    });

    // Create lesson purchase record
    await ctx.db.insert("studentLessons", {
      studentId: student._id,
      lessonId: args.lessonId,
      isPurchased: true,
      hasWatchedVideo: false,
      examAttempts: 0,
      hasPassed: false,
      purchaseDate: Date.now(),
    });

    // Create wallet transaction
    await ctx.db.insert("walletTransactions", {
      studentId: student._id,
      amount: -lesson.price,
      type: "withdrawal",
      description: `Purchased lesson: ${lesson.title}`,
      status: "approved",
      timestamp: Date.now(),
    });

    // Create notification
    await ctx.db.insert("notifications", {
      studentId: student._id,
      title: "Lesson Purchased",
      message: `You have successfully purchased: ${lesson.title}`,
      type: "success",
      isRead: false,
      timestamp: Date.now(),
    });

    return "Lesson purchased successfully";
  },
});

// Get student's purchased lessons
export const getStudentLessons = query({
  args: {},
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      return [];
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      return [];
    }

    const studentLessons = await ctx.db
      .query("studentLessons")
      .withIndex("by_student", (q) => q.eq("studentId", student._id))
      .filter((q) => q.eq(q.field("isPurchased"), true))
      .collect();

    return Promise.all(
      studentLessons.map(async (studentLesson) => {
        const lesson = await ctx.db.get(studentLesson.lessonId);
        if (!lesson) return null;

        return {
          ...studentLesson,
          lesson: {
            ...lesson,
            coverImageUrl: await ctx.storage.getUrl(lesson.coverImage),
            videoUrl: studentLesson.hasWatchedVideo && studentLesson.hasPassed 
              ? await ctx.storage.getUrl(lesson.videoUrl) 
              : null,
            pdfUrl: studentLesson.hasWatchedVideo && studentLesson.hasPassed 
              ? await ctx.storage.getUrl(lesson.pdfUrl) 
              : null,
            homeworkUrl: studentLesson.hasWatchedVideo && studentLesson.hasPassed 
              ? await ctx.storage.getUrl(lesson.homeworkUrl) 
              : null,
            homeworkSolutionUrl: studentLesson.hasWatchedVideo && studentLesson.hasPassed 
              ? await ctx.storage.getUrl(lesson.homeworkSolutionUrl) 
              : null,
          },
        };
      })
    ).then(results => results.filter(Boolean));
  },
});

// Mark video as watched
export const markVideoWatched = mutation({
  args: {
    lessonId: v.id("lessons"),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    const studentLesson = await ctx.db
      .query("studentLessons")
      .withIndex("by_student_lesson", (q) => 
        q.eq("studentId", student._id).eq("lessonId", args.lessonId)
      )
      .first();

    if (!studentLesson) {
      throw new Error("Lesson not purchased");
    }

    await ctx.db.patch(studentLesson._id, {
      hasWatchedVideo: true,
    });

    return "Video marked as watched";
  },
});

// Submit exam
export const submitExam = mutation({
  args: {
    lessonId: v.id("lessons"),
    answers: v.array(v.number()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) {
      throw new Error("User must be authenticated");
    }

    const student = await ctx.db
      .query("students")
      .withIndex("by_user", (q) => q.eq("userId", userId))
      .first();

    if (!student) {
      throw new Error("Student not found");
    }

    const studentLesson = await ctx.db
      .query("studentLessons")
      .withIndex("by_student_lesson", (q) => 
        q.eq("studentId", student._id).eq("lessonId", args.lessonId)
      )
      .first();

    if (!studentLesson) {
      throw new Error("Lesson not purchased");
    }

    if (!studentLesson.hasWatchedVideo) {
      throw new Error("Must watch video first");
    }

    if (studentLesson.examAttempts >= 3) {
      throw new Error("Maximum attempts reached");
    }

    const lesson = await ctx.db.get(args.lessonId);
    if (!lesson) {
      throw new Error("Lesson not found");
    }

    // Calculate score
    let correctAnswers = 0;
    lesson.examQuestions.forEach((question, index) => {
      if (args.answers[index] === question.correctAnswer) {
        correctAnswers++;
      }
    });

    const score = (correctAnswers / lesson.examQuestions.length) * 100;
    const passed = score >= 50;

    await ctx.db.patch(studentLesson._id, {
      examAttempts: studentLesson.examAttempts + 1,
      examScore: score,
      hasPassed: passed,
    });

    // Create notification
    const notificationMessage = passed 
      ? `Congratulations! You passed the exam with ${score.toFixed(1)}%`
      : `You scored ${score.toFixed(1)}%. You have ${3 - studentLesson.examAttempts - 1} attempts remaining.`;

    await ctx.db.insert("notifications", {
      studentId: student._id,
      title: passed ? "Exam Passed!" : "Exam Failed",
      message: notificationMessage,
      type: passed ? "success" : "warning",
      isRead: false,
      timestamp: Date.now(),
    });

    return {
      score,
      passed,
      attemptsRemaining: 3 - studentLesson.examAttempts - 1,
    };
  },
});
